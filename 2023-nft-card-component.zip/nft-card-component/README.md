# NFT Card Component

A Pen created on CodePen.io. Original URL: [https://codepen.io/kiberbash/pen/MWEpevg](https://codepen.io/kiberbash/pen/MWEpevg).

NFT card component with glassmorphism and highlighted hover transition